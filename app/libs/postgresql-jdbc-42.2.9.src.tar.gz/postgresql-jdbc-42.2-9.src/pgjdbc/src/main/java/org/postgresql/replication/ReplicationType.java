/*
 * Copyright (c) 2017, PostgreSQL Global Development Group
 * See the LICENSE file in the project root for more information.
 */

package org.postgresql.replication;

public enum ReplicationType {
  LOGICAL,
  PHYSICAL
}
